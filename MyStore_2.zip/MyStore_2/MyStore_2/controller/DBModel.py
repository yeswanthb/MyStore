
import psycopg2
from utils.properties import (postgres_db_name,
                              postgres_user,
                              postgres_password,
                              postgres_host,
                              postgres_port)
from flask import jsonify
from logs.logs_provider import log

class DBQueries:
    """
    Connects to the DB , returns the queries on passing the variables and executes the queries.
    """
    def __init__(self) -> object:
        """
        To Initialize the class
        """
        super(DBQueries, self).__init__()
        self.log = log
        
    def get_items_from_store(self, select_var: str, table_name: str, store_name: str, item_name: str):
        """
        Returns the select query for the table name by adding the conditions.
        """
        query = "select {select_var} from {table_name} where item_name = '{item_name}' and store_name = '{store_name}';"
        query = query.format(select_var=select_var,table_name=table_name, item_name=item_name, store_name=store_name)
        self.log.info("Query response == %s " ,query)
        return query
    
    def insert_into_store(self, custId,
                                 storeName,
                                 item_id,
                                 item_name,
                                 item_quantity,
                                 item_unit_cost):
        """
        To Insert data into db
        :return: Query response
        """
        try:
            self.log.info("DBQueries:insert_into_store(): Inserting data into storemodel")
            query = "insert into storemodel values(%s,%s, %s, %s, %s, %s)"
            # connecting database and executing the query
            values = (custId,
                      storeName,
                      item_id,
                      item_name,
                      item_quantity,
                      item_unit_cost)
            conn = psycopg2.connect(database=postgres_db_name, user=postgres_user, password=postgres_password,
                                    host=postgres_host, port=postgres_port)
            cursor = conn.cursor()
            result = cursor.execute(query)
            self.log.info("DBQueries:Inserted data into storemodel")
            return result
        except:
            pass
        finally:
            pass
    
    def delete_from_store(self, itemid: str,storename:str):
        try:
            query = "delete from storemodel where item_id = %s"
            # connecting database and executing the query
            conn = psycopg2.connect(database=postgres_db_name, user=postgres_user, password=postgres_password,
                                    host=postgres_host, port=postgres_port)
            cursor = conn.cursor()
            result = cursor.execute(query)
        except:
            pass
        finally:
            pass
        

