import requests
import json
from flask_restful import Resource
from flask import jsonify
from controller.DBModel import DBQueries
from logs.logs_provider import log
from flask import request


def error_dict(error_msg, error_code):
    error_dict = {}
    error_dict['message'] = error_msg
    error_dict['code'] = error_code
    return error_dict


class StoreStatusData(Resource):
    def __init__(self):
        """
        To Initialize the class
        """
        super(StoreStatusData, self).__init__()
        self.log = log

    def get(self, storeName, itemName):
        """
        :param storeName:
        :param itemName:
        """
        try:
            
            self.log.info("StoreStatusData:get(): Enter: TO get the details of current store %s", storeName)
            db_object = DBQueries()
            query = db_object.get_items_from_store("item_list", "itemdetails", storeName, itemName)
            item_list = db_object.db_query(query)  # Getting the list of items  for the store id
            items = []
            for each_item in item_list:
                # Impelemnt business logic to get list of required items and put in other list    
                items.append(each_item)
            self.log.info("StoreStatusData:get(): Exit: Successfully fetched all items from store")
            return items
        except Exception as ex:
            self.log.info("Exception while retrieving data from itemdetails table  ----- %s" ,ex)
            monitor_response = jsonify(error_dict("Items Service down", 400))
            monitor_response.status_code = 400
            return monitor_response
        finally:
            #close connection,files etc.,

    def post(self, custId, storeName):
        try:
            # Retrieve payload data from request here
            req_data = request.get_json()
            item_id = req_data["itemid"]
            item_name = req_data["itemname"]
            item_quantity = req_data["itemquantity"]
            item_unit_cost = req_data["itemunitcost"]
            db_object = DBQueries()
            result = db_object.insert_into_store(custId, storeName, item_id, item_name, item_quantity, item_unit_cost)
            return result
        except Exception:
            response = jsonify(error_dict("Items Service down", 400))
            response.status_code = 400
            return response
        finally:
            #close connection,files etc.,
        
    def delete(self,itemId, storeName):
        try:
            db_object = DBQueries()
            db_object.delete_from_store(itemId,storeName)    
            db_object = DBQueries()
            pass
        except Exception:
            response = jsonify(error_dict("Items Service down", 400))
            response.status_code = 400
            return response
        finally:
            #close connection,files etc.,
    