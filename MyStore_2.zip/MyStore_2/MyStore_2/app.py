from controller import app
from logs.log_provider import log

from utils.properties import (reporting_service_host, reporting_service_port)

def initiator():
    log.info("flaskhost == %s", custom_host)
    log.info("flaskport == %s", custom_port)
    app.run(host=custom_host, port=int(custom_port))


if __name__ == '__main__':
    initiator()