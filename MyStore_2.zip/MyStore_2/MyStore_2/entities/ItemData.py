

class ItemData(object):
    """
    The model of a inventory store.
    """
    def __init__(self, item_id: str, item_name: str, item_desc: str, price: list,
                 available_quantity: str):
        self.item_id = item_id
        self.item_name = item_name
        self.item_desc = item_desc
        self.price = price
        self.available_quantity = available_quantity
