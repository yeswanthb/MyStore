import logging

# Setting the format for the logs
logging.basicConfig(format='%(thread)d - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
log = logging.getLogger("MYSTORE_Reporting_Service")  # Getting the log object
