
class StoreData(object):
    """
    The model of a inventory store.
    """
    def __init__(self, store_id: str, store_name: str, store_address: str, store_loc: list,
                 store_grade: str):
        self.store_id = store_id
        self.store_name = store_name
        self.store_address = store_address
        self.store_loc = store_loc
        self.store_grade = store_grade
