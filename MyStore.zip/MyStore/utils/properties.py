
import os

default_postgres_host = 'localhost'
default_postgres_port = 8080
default_postgres_user = 'postgres'
default_postgres_password = 'root'
default_postgres_db = 'root'

default_reporting_service_host = '0.0.0.0'
default_reporting_service_port = 3000

reporting_service_host = os.getenv('MYSTORE_REPORTING_HOST', default_reporting_service_host)
reporting_service_port = os.getenv('MYSTORE_REPORTING_PORT', default_reporting_service_port)

postgres_host = os.getenv('MYSTORE_POSTGRES_HOST', default_postgres_host)
postgres_port = os.getenv('MYSTORE_POSTGRES_PORT', default_postgres_port)
postgres_user = os.getenv('MYSTORE_POSTGRES_USER', default_postgres_user)
postgres_password = os.getenv('MYSTORE_POSTGRES_PASSWORD', default_postgres_password)
postgres_db_name = os.getenv('MYSTORE_POSTGRES_DBNAME', default_postgres_db)
