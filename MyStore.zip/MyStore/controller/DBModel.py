
import psycopg2
from utils.properties import (postgres_db_name,
                              postgres_user,
                              postgres_password,
                              postgres_host,
                              postgres_port)
from flask import jsonify
from logs.logs_provider import log

class DBQueries:
    """
    Connects to the DB , returns the queries on passing the variables and executes the queries.
    """
    def __init__(self) -> object:
        """
        To Initialize the class
        """
        super(DBQueries, self).__init__()
        self.log = log
        
    def get_device_select_query(self, select_var: str, table_name: str, store_name: str, item_name: str):
        """
        Returns the select query for the table name by adding the conditions.
        """
        query = "select {select_var} from {table_name} where item_name = '{item_name}' and store_name = '{store_name}';"
        query = query.format(select_var=select_var,table_name=table_name, item_name=item_name, store_name=store_name)
        self.log.info("Query response == %s " ,query)
        return query
    
    """
    Implement queries for other CRUD opreations like insert,update,delete
    """
    