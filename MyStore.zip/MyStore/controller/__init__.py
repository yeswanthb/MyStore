from flask import Flask
from flask_restful import Api

from controller.CurrentStatusController import StoreStatusData

app = Flask(__name__)
app.debug = True
api = Api(app)


'''

Client requests:
-----------------
To delete one existing item from my store in shopping cart application
DELETE : http://localhost:3000/api/v1/storeservice/storehistory/itemid/2/mystore/teststore_28-07-2018/deletereport

To retrieve items from respective store 
GET    : http://localhost:3000/api/v1/datasetservice/mystore/<storename>/item/<itemname>
         
To upload new store details and its items
POST   : http://localhost:3000/api/v1/StoreParserService/customerId/<custid>/uploaditems


'''


api.add_resource(StoreStatusData, 'api/v1/datasetservice/mystore/<storeName>/item/<itemName>')                          # GET
api.add_resource(StoreStatusData, '/api/v1/StoreParserService/customerId/<custid>/uploaditems')                         # POST
api.add_resource(StoreStatusData, '/api/v1/storeservice/storehistory/itemid/<itemName>/mystore/<storeName>/deletereport') # DELETE





